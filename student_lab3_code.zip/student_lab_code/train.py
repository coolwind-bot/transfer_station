import time
from deeprobust.graph.data import PrePtbDataset, Dataset, Dpr2Pyg
from deeprobust.graph.defense import *
from deeprobust.graph.utils import *
import numpy as np
from prettytable import PrettyTable

if __name__ == '__main__':
    method = 'meta'
    if method == 'meta':
        ptb_rates = [0, 0.05, 0.1, 0.15, 0.2, 0.25]
    elif method == 'nettack':
        ptb_rates = [0, 1.0, 2.0, 3.0, 4.0, 5.0]
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    table = PrettyTable(field_names=['Ptb. Rate', 'Accuracy'])
    for ptb_rate in ptb_rates:
        acc = []
        for i in range(10):
            seed = int(time.time())
            torch.manual_seed(seed)
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
            data = Dataset(root='./data/', name='cora', setting='nettack', seed=666)
            adj, features, labels = data.adj, data.features, data.labels
            idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test
            if ptb_rate == 0.0:
                perturbed_adj = adj
            else:
                perturbed_data = PrePtbDataset(root='./data/perturbed/',
                                                name='cora',
                                                attack_method=method,
                                                ptb_rate=ptb_rate)
                perturbed_adj = perturbed_data.adj
            model = GCN(nfeat=features.shape[1],
                    nhid=64,
                    nclass=labels.max().item() + 1, device=device)
            model.fit(features, perturbed_adj, labels, idx_train)
            output = model.output.cpu()
            # loss_test = F.nll_loss(output[idx_test], labels[idx_test])
            acc_test = accuracy(output[idx_test], labels[idx_test]).item() * 100
            acc.append(acc_test)
        table.add_row([ptb_rate, '{:.2f}±{:.2f}'.format(np.mean(acc), np.std(acc))])
    print(table)